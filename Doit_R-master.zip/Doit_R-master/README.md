﻿<Do it! 쉽게 배우는 R 데이터 분석> 저장소
---
- [Data](https://github.com/youngwoos/Doit_R/tree/master/Data) 폴더에 실습에 필요한 데이터 파일이 들어있습니다.

- 한국복지패널데이터는 아래 링크를 통해 다운받을 수 있습니다.
    + [Koweps_hpc10_2015_beta1.sav](http://bit.ly/Koweps_hpc10_2015_v2)
- [Script](https://github.com/youngwoos/Doit_R/tree/master/Script) 폴더에 본문에 사용된 R 스크립트와 퀴즈, 분석 도전의 정답 스크립트가 들어있습니다.
- 강의용 프리젠테이션 파일을 [Lecture](https://github.com/youngwoos/Doit_R/tree/master/Lecture)에서 다운받으실 수 있습니다.

## 질문하기
궁금한 점이 있으면 페이스북 [데이터 분석 커뮤니티](https://www.facebook.com/groups/datacommunity)에 질문을 올려 주세요. 이곳에서는 데이터 분석을 공부하기 시작한 사람들이 활동하고 있으니 질문과 답변을 주고받으면서 함께 공부할 수 있습니다. 질문할 때 작성한 코드나 캡쳐 이미지를 함께 올려 주시면 답변하는 데 도움이 됩니다.

깃허브의 [이슈](https://github.com/youngwoos/Doit_R/issues/1)에 질문을 올려주셔도 좋습니다.

## 기타 문의
다른 문의 사항은 stats7445@gmail.com으로 메일을 보내주세요.
